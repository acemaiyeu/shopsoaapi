# Security Policy

**PLEASE DON'T DISCLOSE SECURITY-RELATED ISSUES PUBLICLY, [SEE BELOW](#reporting-a-vulnerability).**

## Reporting a Vulnerability

If you discover any security related issues, please email security@akaunting.com instead of using the issue tracker.
